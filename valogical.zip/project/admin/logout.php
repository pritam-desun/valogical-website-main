<?php
include("include/master.php");
session_destroy();
header("location:login.php");
?>