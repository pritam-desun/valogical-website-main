<?php
include("include/master.php");
include("include/footer.php");
?>